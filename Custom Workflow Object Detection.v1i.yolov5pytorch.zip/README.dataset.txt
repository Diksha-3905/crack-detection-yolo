# Custom Workflow Object Detection > 2025-07-26 9:18pm
https://universe.roboflow.com/crackdetection-owfgz/custom-workflow-object-detection-rurvq

Provided by a Roboflow user
License: CC BY 4.0

